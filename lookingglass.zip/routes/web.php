<?php

use App\Http\Controllers\DnsController;
use App\Http\Controllers\HomeControler;
use App\Http\Controllers\MtrController;
use App\Http\Controllers\NetworkController;
use App\Http\Controllers\PingController;
use App\Http\Controllers\SpeedController;
use App\Http\Controllers\TracerouteController;
use App\Http\Controllers\WebController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        



Route::controller(NetworkController::class)->group(function(){
    Route::get('/', 'index')->name('network.index');
    Route::post('/ping', 'ping')->name('network.ping');
    Route::post('/ping6', 'ping6')->name('network.ping6');
    Route::post('/traceroute', 'traceroute')->name('network.traceroute');
    Route::post('/traceroute6', 'traceroute6')->name('network.traceroute6');
    Route::post('/ipinfo', 'ipinfo')->name('network.ipinfo');
});

Route::controller(WebController::class)->group(function(){
    Route::get('/webtool', 'index')->name('web.index');
    Route::post('/whois', 'whois')->name('web.whois');
    Route::post('/dnslookup', 'lookup')->name('web.lookup');
    Route::post('/brotli', 'brotli')->name('web.brotli');
    Route::post('/httphc', 'httphc')->name('web.httphc');
    Route::post('/wst', 'webspeed')->name('web.webspeed');
});

Route::controller(SpeedController::class)->group(function(){
    Route::get('/speed', 'index')->name('speed.index');
    Route::post('/speed/test', 'test')->name('speed.test');
});
