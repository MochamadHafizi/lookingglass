
<?php $__env->startSection('content'); ?>
<aside id="default-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
    <div class="h-full px-3 py-4 overflow-y-auto bg-gray-50">
        <img src="/img/logo/jh.png" alt="Image" width="50" height="50" class="mx-auto mb-4 mt-5 rounded-full">
        <div class="grid mb-10 w-full place-items-center mt-20">
            <div class="">
                <ul class="space-y-2">
                    <li>
                        <div class="py-2">
                            <input type="radio" id="1" value="ping" name="action" class="peer hidden" checked />
                            <label for="1" class="block cursor-pointer select-none rounded-xl p-2 text-center">Ping</label>
                        </div>
                    </li>
                    <li>
                        <div class="py-2">
                            <input type="radio" id="2" value="traceroute" name="action" class="peer hidden" />
                            <label for="2" class="block cursor-pointer select-none rounded-xl p-2 text-center">Traceroute</label>
                        </div>
                    </li>
                    <li>
                        <div class="py-2">
                            <input type="radio" id="3" value="ipinfo" name="action" class="peer hidden" />
                            <label for="3" class="block cursor-pointer select-none rounded-xl p-2 text-center">IP Info</label>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="grid mb-10 w-full place-items-center">
            <div class="">
                <ul class="space-y-2">
                    <li>
                        <div class="py-2">
                            <input type="radio" id="ipv4" value="ipv4" name="ip"  class="peer hidden" checked/>
                            <label for="ipv4" class="block cursor-pointer select-none rounded-xl p-2 text-center">IPV4</label>
                        </div>
                    </li>
                    <li>
                        <div class="py-2">
                            <input type="radio" id="ipv6" value="ipv6" name="ip"  class="peer hidden" />
                            <label for="ipv6" class="block cursor-pointer select-none rounded-xl p-2 text-center">IPV6</label>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</aside>

<section>
    <div class="flex justify-center mt-28">	
<form class="w-1/2 shadow-md my-5 py-5 px-5 bg-gray-50" method="POST" id="myForm">
            <?php echo csrf_field(); ?>             
                    <div class="relative z-0 w-full mb-6 group">
                        <input type="text" name="domain" id="domain" class="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none focus:outline-none focus:ring-0 focus:border-orange-500 peer" placeholder=" " required  onchange="validateDomainOrIP(this.value)"/>
                        <label for="domain" class="peer-focus:font-medium absolute text-sm text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-orange-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Domain / IP</label>
                        <div id="error-message" class="text-red-500 mt-2"></div>
                    </div>
                    <div class="g-recaptcha relative z-0 w-full mb-6 group" data-sitekey="<?php echo e(env('RECAPTCHA_SITE_KEY')); ?>" data-callback="onRecaptchaCallback"></div>
                    <div class="flex items-start mb-6"></div>
                    <button onclick="submitForm()" type="submit" id="submitBtn" class="cursor-not-allowed relative inline-flex items-center justify-center p-5 px-6 py-2 overflow-hidden font-bold text-orange-600 transition duration-300 ease-out border-2 border-orange-500 rounded-full shadow-md group" disabled>
                    <span class="absolute inset-0 flex items-center justify-center w-full h-full text-white duration-300 -translate-x-full bg-orange-500 group-hover:translate-x-0 ease">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                    </span>
                    <span class="absolute flex items-center justify-center w-full h-full text-orange-500 transition-all duration-300 transform group-hover:translate-x-full ease">Kirim</span>
                    <span class="relative invisible">Kirim</span>
                    </button>
                    <?php if(isset($pingResults)): ?>
                        <h2 class="text-2xl font-semibold mb-4">Hasil Ping:</h2>
                        <div class="overflow-x-auto">
                            <table class="table-auto min-w-full border-collapse">
                                <thead>
                                    <tr>
                                        <th class="px-4 py-2 bg-gray-200 text-left">Attempt</th>
                                        <th class="px-4 py-2 bg-gray-200 text-left">Ping Time</th>
                                        <th class="px-4 py-2 bg-gray-200 text-left">IP Address</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pingResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="border px-4 py-2"><?php echo e($resultping['attempt']); ?></td>
                                            <td class="border px-4 py-2"><?php echo e($resultping['pingTime']); ?> ms</td>
                                            <td class="border px-4 py-2"><?php echo e($resultping['ipAddress']); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($outputrace)): ?>
                    <h2>Hasil Traceroute <?php echo e($domain); ?> : </h2>
                    <pre><?php echo e($outputrace); ?></pre>
                    <?php endif; ?>
                    <?php if(isset($outputrace6)): ?>
                    <h2>Hasil Traceroute <?php echo e($domain); ?> : </h2>
                    <pre><?php echo e($outputrace6); ?></pre>
                    <?php endif; ?>
                    <?php if(isset($api_result)): ?>
                        <h2 class="text-xl font-semibold mb-4">IP Location Information:</h2>
                        <div class="overflow-x-auto">
                            <table class="min-w-full bg-white border rounded-lg shadow-lg">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th class="py-2 px-4 text-left">Field</th>
                                        <th class="py-2 px-4 text-left">Value</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $api_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="py-2 px-4 border-t font-bold"><?php echo e($key); ?></td>
                                            <td class="py-2 px-4 border-t text-green-600"><?php echo e($value); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($result)): ?>
                    <h2>Ping Result:</h2>
                    <p>IPv6 Address: <?php echo e($domain); ?></p>
                    <pre><?php echo e($result); ?></pre>
                    <?php endif; ?>

                </form>	
       
    </div>
</section>


<script>
    // Callback saat reCAPTCHA selesai dicentang
    function onRecaptchaCallback() {
      const submitButton = document.getElementById('submitBtn');
      submitButton.disabled = false; // Tombol diaktifkan ketika reCAPTCHA telah dicentang
      submitButton.classList.remove('cursor-not-allowed'); // Menghapus class cursor-not-allowed
    }
  
    // Panggil fungsi untuk menonaktifkan tombol saat halaman dimuat
    document.addEventListener('DOMContentLoaded', function() {
      const submitButton = document.getElementById('submitBtn');
      submitButton.disabled = true;
    });
  
  </script>

<script>
  function submitForm() {
      var radios = document.getElementsByName("action");
      var ip = document.getElementsByName("ip");
      var selectedAction;
      var selectedIp;

      // Cari tindakan dan alamat IP yang dipilih
      for (var i = 0; i < radios.length; i++) {
          if (radios[i].checked) {
              selectedAction = radios[i].value;
              break;
          }
      }

      for (var i = 0; i < ip.length; i++) {
          if (ip[i].checked) {
              selectedIp = ip[i].value;
              break;
          }
      }

      var form = document.getElementById("myForm");

      if (selectedAction === "ping" && selectedIp === "ipv4") {
          // Arahkan form ke ping controller (untuk ping dengan IPv4)
          form.action = "/ping";
      } else if (selectedAction === "ping" && selectedIp === "ipv6") {
          // Arahkan form ke ping6 controller (untuk ping dengan IPv6)
          form.action = "/ping6";
      } else if (selectedAction === "traceroute" && selectedIp ==="ipv4") {
          // Arahkan form ke traceroute controller
          form.action = "/traceroute";
      } else if (selectedAction === "traceroute" && selectedIp ==="ipv6") {
          // Arahkan form ke traceroute controller
          form.action = "/traceroute6";
      }  
        else if (selectedAction === "ipinfo") {
          // Arahkan form ke ipinfo controller
          form.action = "/ipinfo";
      }

      form.submit();
  }
</script>
<script>
    // Regex untuk validasi domain, alamat IPv4, dan alamat IPv6
    var domainRegex = /^(?:(?=[a-zA-Z0-9-]{1,63}\.)[a-zA-Z0-9]+(?:-[a-zA-Z0-9]+)*\.)+[a-zA-Z]{2,63}$/;
    var ipv4Regex = /^(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var ipv6Regex = /^((?:(?:(?:[a-fA-F0-9]{1,4}:){6}(?:[a-fA-F0-9]{1,4}:)?|::(?:[a-fA-F0-9]{1,4}:){5}(?:[a-fA-F0-9]{1,4}:)?(?:[a-fA-F0-9]{1,4})?|(?:[a-fA-F0-9]{1,4})?::(?:[a-fA-F0-9]{1,4}:){4}(?:[a-fA-F0-9]{1,4}:)?(?:[a-fA-F0-9]{1,4}){0,2}|(?:[a-fA-F0-9]{1,4}){0,1}::(?:[a-fA-F0-9]{1,4}:){3}(?:[a-fA-F0-9]{1,4}:)?(?:[a-fA-F0-9]{1,4}){0,3}|(?:[a-fA-F0-9]{1,4}){0,2}::(?:[a-fA-F0-9]{1,4}:){2}(?:[a-fA-F0-9]{1,4}:)?(?:[a-fA-F0-9]{1,4}){0,4}|(?:[a-fA-F0-9]{1,4}){0,3}::(?:[a-fA-F0-9]{1,4}:)(?:[a-fA-F0-9]{1,4}:)?(?:[a-fA-F0-9]{1,4}){0,5}|(?:[a-fA-F0-9]{1,4}){0,4}::(?:[a-fA-F0-9]{1,4}:)?(?:[a-fA-F0-9]{1,4}:)(?:[a-fA-F0-9]{1,4}){0,6}|(?:[a-fA-F0-9]{1,4}){0,5}::(?:[a-fA-F0-9]{1,4}:)(?:[a-fA-F0-9]{1,4}:)?(?:[a-fA-F0-9]{1,4}){0,7}|(?:[a-fA-F0-9]{1,4}){0,6}::(?:[a-fA-F0-9]{1,4}:)?(?:[a-fA-F0-9]{1,4}){0,8}|(?:[a-fA-F0-9]{1,4}){0,7}::(?:[a-fA-F0-9]{1,4}:)(?:[a-fA-F0-9]{1,4}){0,9}|(?:[a-fA-F0-9]{1,4}){0,8}::(?:[a-fA-F0-9]{1,4}:)?(?:[a-fA-F0-9]{1,4}){0,10})(?:[a-fA-F0-9]{1,4}:[a-fA-F0-9]{1,4}|(?<=:):(?=:)|(?<=:):|:(?=:|$))|[a-fA-F0-9]{1,4}(?::[a-fA-F0-9]{1,4}){1,5}|(?:(?:(?:(?::[a-fA-F0-9]{1,4}){1,6})?:[a-fA-F0-9]{1,4})|(?:(?:(?::[a-fA-F0-9]{1,4}){1,6})?::(?:(?::[a-fA-F0-9]{1,4}){1,6})?)))(?<![^:])$/;
  
    function validateDomainOrIP(inputValue) {
      var errorMessageElement = document.getElementById("error-message");
      errorMessageElement.innerText = ""; // Hapus pesan error sebelumnya
  
      if (!domainRegex.test(inputValue) && !ipv4Regex.test(inputValue) && !ipv6Regex.test(inputValue)) {
        errorMessageElement.innerText = "Input tidak valid. Masukkan domain atau IP yang valid.";
      }
    }
  </script>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODING\lookingglass\resources\views/network/main.blade.php ENDPATH**/ ?>