
<?php $__env->startSection('content'); ?>
<aside id="default-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
    <div class="h-full px-3 py-4 overflow-y-auto bg-gray-50">
        <img src="/img/logo/jh.png" alt="Image" width="50" height="50" class="mx-auto mb-4 mt-5 rounded-full">
        <div class="grid mb-10 w-full place-items-center mt-20">
            <div class="">
                <ul class="space-y-2">
                    <li>
                        <div class="py-2">
                            <input type="radio" id="1" value="whois" name="action" class="peer hidden" checked />
                            <label for="1" class="block cursor-pointer select-none rounded-xl p-2 text-center">Who Is</label>
                        </div>
                    </li>
                    <li>
                        <div class="py-2">
                            <input type="radio" id="2" value="wst" name="action" class="peer hidden" />
                            <label for="2" class="block cursor-pointer select-none rounded-xl p-2 text-center">Web Speed Test</label>
                        </div>
                    </li>
                    <li>
                        <div class="py-2">
                            <input type="radio" id="4" value="httphc" name="action" class="peer hidden" />
                            <label for="4" class="block cursor-pointer select-none rounded-xl p-2 text-center">HTTP Header Checker</label>
                        </div>
                    </li>
                    <li>
                        <div class="py-2">
                            <input type="radio" id="5" value="dnslookup" name="action" class="peer hidden" />
                            <label for="5" class="block cursor-pointer select-none rounded-xl p-2 text-center">DNS Loookup</label>
                         </div>
                    </li>
                    <li>
                        <div class="py-2">
                            <input type="radio" id="6" value="brotli" name="action" class="peer hidden" />
                            <label for="6" class="block cursor-pointer select-none rounded-xl p-2 text-center">Brotli Test</label>
                       </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</aside>
<section>
    <div class="flex justify-center mt-28">	
        <form class="w-1/2 shadow-md my-5 py-5 px-5 bg-gray-50" method="POST" id="myForm">
            <?php echo csrf_field(); ?>
                <div class="relative z-0 w-full mb-6 group">
                        <input value="" type="text" name="requestUrl" id="domain" class="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none focus:outline-none focus:ring-0 focus:border-orange-500 peer" placeholder=" " required  onchange="validateDomainOrIP(this.value)"/>
                        <label for="domain" class="peer-focus:font-medium absolute text-sm text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-orange-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Domain / URL</label>
                        
                    </div>
                    <div class="g-recaptcha relative z-0 w-full mb-6 group" data-sitekey="<?php echo e(env('RECAPTCHA_SITE_KEY')); ?>" data-callback="onRecaptchaCallback"></div>
                    <div class="flex items-start mb-6"></div>
                    <button onclick="submitForm()" type="submit" id="submitBtn" class="cursor-not-allowed relative inline-flex items-center justify-center p-5 px-6 py-2 overflow-hidden font-bold text-orange-600 transition duration-300 ease-out border-2 border-orange-500 rounded-full shadow-md group" disabled>
                    <span class="absolute inset-0 flex items-center justify-center w-full h-full text-white duration-300 -translate-x-full bg-orange-500 group-hover:translate-x-0 ease">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                    </span>
                    <span class="absolute flex items-center justify-center w-full h-full text-orange-500 transition-all duration-300 transform group-hover:translate-x-full ease">Kirim</span>
                    <span class="relative invisible">Kirim</span>
                    </button>
                    <?php if(isset($result)): ?>
                        <h2 class="text-xl font-semibold mb-4">Domain WHOIS Information:</h2>
                        <div class="overflow-x-auto">
                            <table class="min-w-full bg-white border rounded-lg shadow-lg">
                                <tbody>
                                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key === 'billing'): ?>
                                            <?php continue; ?>
                                        <?php endif; ?>
                                        <?php if(is_array($value)): ?>
                                            <tr>
                                                <td colspan="2" class="py-2 px-4 bg-gray-100 font-semibold"><?php echo e($key); ?></td>
                                            </tr>
                                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $innerKey => $innerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="py-2 px-4 border-t"><?php echo e($innerKey); ?></td>
                                                    <td class="py-2 px-4 border-t"><?php echo e($innerValue); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td class="py-2 px-4 border-t"><?php echo e($key); ?></td>
                                                <td class="py-2 px-4 border-t"><?php echo e($value); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($hasilhttp)): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white border rounded-lg shadow-lg">
                            <tbody>
                                <?php $__currentLoopData = $hasilhttp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-2 px-4 bg-gray-100 font-semibold"><?php echo e($key); ?></td>
                                        <td class="py-2 px-4">
                                            <?php if(is_array($value)): ?>
                                                <pre><?php echo e(json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)); ?></pre>
                                            <?php else: ?>
                                                <?php echo e($value); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                    <?php if(isset($isBrotliCompressed) == true): ?>
                        <?php if(isset($isBrotliCompressed)): ?>
                        <div class="bg-green-100 mt-5 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                            <strong class="font-bold">URL domain menggunakan kompresi Brotli</strong>
                            <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
                              <svg class="fill-current h-6 w-6 text-green-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
                            </span>
                          </div>
                        <?php else: ?>
                        <div class="bg-red-100 mt-5 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                            <strong class="font-bold">URL domain tidak menggunakan kompresi Brotli</strong>
                            <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
                              <svg class="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
                            </span>
                          </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if(isset($resultdns)): ?>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border rounded-lg shadow-lg">
            <tbody>
                <?php
                    $groupedRecords = [];
                    foreach ($resultdns as $record) {
                        $recordType = $record['record_type'];
                        unset($record['record_type']);
                        if (!isset($groupedRecords[$recordType])) {
                            $groupedRecords[$recordType] = [];
                        }
                        $groupedRecords[$recordType][] = $record;
                    }
                ?>

                <?php $__currentLoopData = $groupedRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recordType => $records): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="2" class="py-2 px-4 bg-gray-100 font-semibold"><?php echo e($recordType); ?></td>
                    </tr>
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="py-2 px-4 bg-gray-100 font-semibold"><?php echo e($key); ?></td>
                                <td class="py-2 px-4"><?php echo e($value); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php if(isset($pageSpeedData)): ?>
            <p class="mb-2">URL: <?php echo e($pageSpeedData['id']); ?></p>
            <p class="mb-4">Performance Score: <?php echo e($pageSpeedData['lighthouseResult']['categories']['performance']['score']); ?></p>
            
            <h2 class="text-lg font-semibold mb-2">Page Stats</h2>
            <ul class="list-disc pl-6 mb-4">
                <li>First Contentful Paint: <?php echo e($pageSpeedData['loadingExperience']['metrics']['FIRST_CONTENTFUL_PAINT_MS']['percentile']); ?> ms</li>
                <li>First Input Delay: <?php echo e($pageSpeedData['loadingExperience']['metrics']['FIRST_INPUT_DELAY_MS']['percentile']); ?> ms</li>
                <!-- Add more page stats as needed -->
            </ul>

            <h2 class="text-lg font-semibold mb-2">Opportunities for Improvement</h2>
            <?php $__currentLoopData = $pageSpeedData['lighthouseResult']['audits']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($audit['score'] < 1): ?>
                    <div class="mb-4">
                        <p class="text-red-600 font-semibold"><?php echo e($audit['title']); ?> - Score: <?php echo e($audit['score']); ?></p>
                        <p><?php echo e($audit['description']); ?></p>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
                </form>	
       
    </div>
</section>


<script>
    // Callback saat reCAPTCHA selesai dicentang
    function onRecaptchaCallback() {
      const submitButton = document.getElementById('submitBtn');
      submitButton.disabled = false; // Tombol diaktifkan ketika reCAPTCHA telah dicentang
      submitButton.classList.remove('cursor-not-allowed'); // Menghapus class cursor-not-allowed
    }
  
    // Panggil fungsi untuk menonaktifkan tombol saat halaman dimuat
    document.addEventListener('DOMContentLoaded', function() {
      const submitButton = document.getElementById('submitBtn');
      submitButton.disabled = true;
    });
  
  </script>

<script>
    function submitForm() {
      var radios = document.getElementsByName("action");
    //   var radios = document.getElementsByName("action");
      var selectedAction;

      for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
          selectedAction = radios[i].value;
          break;
        }
      }

      var form = document.getElementById("myForm");

      if (selectedAction === "wst") {
        // Arahkan form ke ping controller
        form.action = "/wst";
      } else if (selectedAction === "pt") {
        // Arahkan form ke traceroute controller
        form.action = "/pt";
      } else if (selectedAction === "httphc") {
        // Arahkan form ke dnslookup controller
        form.action = "/httphc";
      } else if (selectedAction === "dnslookup") {
        // Arahkan form ke dnslookup controller
        form.action = "/dnslookup";
      } else if (selectedAction === "brotli") {
        // Arahkan form ke dnslookup controller
        form.action = "/brotli";
      } else if (selectedAction === "whois") {
        // Arahkan form ke dnslookup controller
        form.action = "/whois";
      }

      form.submit();
    }
  </script>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODING\lookingglass\resources\views/web/main.blade.php ENDPATH**/ ?>