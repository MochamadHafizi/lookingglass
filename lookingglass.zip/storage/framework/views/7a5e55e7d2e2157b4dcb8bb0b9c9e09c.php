
<?php $__env->startSection('content'); ?>
<section>
    <div class="flex justify-center">	
        <form class="w-1/2 shadow-md my-5 py-5 px-5 bg-gray-50" method="POST" id="myForm">
            <?php echo csrf_field(); ?>
                <img src="/img/logo/jh.png" alt="Image" width="50" height="50" class="mx-auto mb-4 mt-20">
                <ul class="items-center w-full text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg sm:flex dark:bg-gray-700 dark:border-gray-600 dark:text-white mb-5">
                    <li class="w-full border-b border-gray-200 sm:border-b-0 sm:border-r dark:border-gray-600">
                        <div class="flex items-center pl-3">
                            <input checked id="horizontal-list-radio-license" type="radio" value="ping" name="action" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                            <label for="horizontal-list-radio-license" class="w-full py-3 ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">Ping</label>
                        </div>
                    </li>
                    <li class="w-full border-b border-gray-200 sm:border-b-0 sm:border-r dark:border-gray-600">
                        <div class="flex items-center pl-3">
                            <input id="horizontal-list-radio-id" type="radio" value="traceroute" name="action" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                            <label for="horizontal-list-radio-id" class="w-full py-3 ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">Traceroute</label>
                        </div>
                    </li>
                    <li class="w-full border-b border-gray-200 sm:border-b-0 sm:border-r dark:border-gray-600">
                        <div class="flex items-center pl-3">
                            <input id="horizontal-list-radio-millitary" type="radio" value="dnslookup" name="action" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                            <label for="horizontal-list-radio-millitary" class="w-full py-3 ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">DNS Lookup</label>
                        </div>
                    </li>
                    
                </ul>                
                    
                    <div class="relative z-0 w-full mb-6 group">
                        <input type="text" name="domain" id="domain" class="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
                        <label for="domain" class="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Domain / IP</label>
                    </div>
                    
                    <div class="flex items-start mb-6">			
                    </div>
                    <button onclick="submitForm()" type="submit" id="submitBtn" class="bg-orange-500 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-md mt-2">Submit</button>
                    <?php if(isset($output)): ?>
                    <h2>Hasil Ping:</h2>    
                    <pre><?php echo e($output); ?></pre>
                    <?php endif; ?>
                    <?php if(isset($outputrace)): ?>
                    <h2>Traceroute Result for <?php echo e($domain); ?></h2>
                    <pre><?php echo e($outputrace); ?></pre>
                    <?php endif; ?>
                    <?php if(isset($result)): ?>
                    <h2>DNS Lookup Result:</h2>
                    <pre><?php echo e(preg_replace('/[{}]/', '', json_encode($result, JSON_PRETTY_PRINT))); ?></pre>
                    <?php endif; ?>
                </form>	
       
    </div>
</section>

<script>
    function submitForm() {
      var radios = document.getElementsByName("action");
      var selectedAction;

      for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
          selectedAction = radios[i].value;
          break;
        }
      }

      var form = document.getElementById("myForm");

      if (selectedAction === "ping") {
        // Arahkan form ke ping controller
        form.action = "/ping";
      } else if (selectedAction === "traceroute") {
        // Arahkan form ke traceroute controller
        form.action = "/traceroute";
      } else if (selectedAction === "dnslookup") {
        // Arahkan form ke dnslookup controller
        form.action = "/dnslookup";
      }

      form.submit();
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODING\lookingglass\resources\views/layouts/ping/main.blade.php ENDPATH**/ ?>