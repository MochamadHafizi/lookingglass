<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use GuzzleHttp\Client;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\MessageFormatter;
use GuzzleHttp\Middleware;


class WebController extends Controller
{
    public function index(){
        $domain = '';
        $result = null;
        // $isBrotliCompressed = null;

        return view('web.main', compact('domain', 'result'));
    }

    public function whois(Request $request)
    {   
        $request->validate([
            'requestUrl' => 'required',
        ]);

        $requestUrl = $request->input('requestUrl');
        $apiKey = '9879F9C725917DA8992F12F5F91EB7F3';

        $response = Http::withHeaders([
            "Content-Type" => "text/plain",
            "apikey" => $apiKey,
        ])->get("https://api.ip2whois.com/v2?key={$apiKey}&domain={$requestUrl}");

        $result = urldecode($response->body());
        $result = json_decode($result, true);

        return view('web.main', compact('requestUrl', 'result'));
    }
    public function httphc(Request $request){
        $requestUrl = $request->input('requestUrl');
        $data = array(
            "requestUrl" => $requestUrl
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.httpstatus.io/v1/status");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8'));

        $resulthttp = curl_exec($ch);
        // $httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);
        $hasilhttp = json_decode($resulthttp, true);
        
        return view('web.main', compact('hasilhttp'));
    }

    public function brotli(Request $request){
        $url = $request->input('requestUrl');
         // Inisialisasi Guzzle HTTP client
         $client = new Client();

         // Tambahkan middleware untuk mencatat permintaan dan responsenya (opsional)
         $stack = HandlerStack::create();
         $stack->push(
             Middleware::log(
                 app('log'),
                 new MessageFormatter(MessageFormatter::DEBUG)
             )
         );
          // Konfigurasi client dengan middleware yang telah ditambahkan
        $client = new Client([
            'handler' => $stack,
        ]);
        try {
            // Kirim permintaan HTTP GET ke URL domain yang diberikan
            $response = $client->get($url);

            // Cek apakah responsenya menggunakan kompresi Brotli
            $isBrotliCompressed = $response->hasHeader('Content-Encoding')
                && $response->getHeader('Content-Encoding')[0] === 'br';
        } catch (\Exception $e) {
            // Jika terjadi error pada permintaan, tandai URL domain tidak menggunakan kompresi Brotli
            $isBrotliCompressed = false;
        }

        return view('web.main', compact('isBrotliCompressed'));
    }
    public function lookup(Request $request)
    {
        $request->validate([
            'requestUrl' => 'required',
        ]);

        $domain = $request->input('requestUrl');
        $apiKey = 'dfzB0ZAMy5j3bXyVFTYNfQ==c1edtYMiexaPyGb2';

        $response = Http::withHeaders([
            'X-Api-Key' => $apiKey,
        ])->get('https://api.api-ninjas.com/v1/dnslookup', [
            'domain' => $domain,    
        ]);

        $resultdns = urldecode($response->body());
        $resultdns = json_decode($resultdns, true);

        return view('web.main', compact('domain', 'resultdns'));
    }
    
    public function webspeed(Request $request){
        $request->validate([
            'requestUrl' => 'required',
        ]);
    
        $url = $request->input('requestUrl');
        $apiKey = 'AIzaSyBz-3djDWPF8o5uhdkTedftkuEt4tlK3Os';
    
        $apiUrl = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url={$url}&key={$apiKey}";
    
        try {
            $response = Http::get($apiUrl);
    
            if ($response->successful()) {
                $pageSpeedData = $response->json();
                return view('web.main', compact('pageSpeedData'));
            } else {
                return "Error: " . $response->status();
            }
        } catch (\Exception $e) {
            return "Error: " . $e->getMessage();
        }
    }
    
}
